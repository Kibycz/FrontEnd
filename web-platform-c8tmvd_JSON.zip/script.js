var JSONObj = {
  nombrelibro: "El hacedor",
  precio:500
};
console.log(JSON.stringify(JSONObj));